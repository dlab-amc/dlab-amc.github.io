---
layout: post
title: '학술대회 테스트 [Academic Conference]'
date: 2025-11-12 00:00:00
featured-img: '/images/posts/202511/thumbnail_image-1762930161222-953090355.png'
short-content: 'Test News Post'
comments: true
---

테스트입니다.


![](/images/posts/202511/88072ee2-ac3d-4cb9-8473-3c5774f2ebfe.png)
