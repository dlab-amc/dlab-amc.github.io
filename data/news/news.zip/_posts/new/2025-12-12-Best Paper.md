---
layout: post
title: "우수논문상 [Best Paper]"
date: 2025-12-12 00:00:00
featured-img: '/images/posts/202512/thumbnail_image-1766119235823-632016222.jpg'
short-content: "대한전기학회 우수 논문상 수상"
comments: true
---

진재욱 학생 (박사과정)이 2025년 대한전기학회 하계학술대회에서 발표한 '수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발'로 우수논문상을 수상하였습니다🎊

![](/images/posts/202512/825e2dc7-2870-4fd6-a488-3bb572bc8023.jpg)
