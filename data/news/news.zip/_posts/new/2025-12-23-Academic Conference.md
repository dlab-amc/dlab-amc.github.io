---
layout: post
title: "학술대회 [Academic Conference]"
date: 2025-12-23 00:00:00
featured-img: '/images/posts/202512/thumbnail_image-1766554801501-794911923.png'
short-content: "ICABB 2025 참석"
comments: true
---

12월 21일부터 23일까지 일본 도쿄대에서 열린 [ICABB](https://www.icabb.org/)에 참석하였습니다.

진재욱 학생 (박사과정)이 "PubMedBERT-Based Terminology Mapping for Surgical Procedure Types”라는 주제로 구연 발표하였습니다🤓📝!

![](/images/posts/202512/7482bbc0-3447-4f8a-bc1e-df69565406d2.jpeg)

