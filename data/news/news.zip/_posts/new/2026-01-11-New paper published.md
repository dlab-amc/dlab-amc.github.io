---
layout: post
title: "Journal of the American Medical Informatics Association 논문 게재 [New paper published]"
date: 2026-01-11 00:00:00
featured-img: '/images/posts/202601/thumbnail_image-1768262082143-393436580.png'
short-content: "유지원 연구원 논문 게재"
comments: true
---

유지원 연구원의 [**‘Structural insights into clinical large language models and their barriers to translational readiness’**](https://academic.oup.com/jamia/advance-article/doi/10.1093/jamia/ocaf230/8419921) 논문이 *Journal of the American Medical Informatics Association* 에 게재되었습니다!🎊

Journal of the American Medical Informatics Association 의 IF(Impact Factor)는 4.6입니다.

논문 게재를 축하드립니다🥳🎉

![](/images/posts/202601/74c6034b-f03b-48b6-82fb-6ad745eb1fbf.png)
