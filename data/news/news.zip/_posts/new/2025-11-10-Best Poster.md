---
layout: post
title: '우수포스터상 [Best Poster]'
date: 2025-11-10 06:33:40
featured-img: '/images/posts/202511/thumbnail_image-1762756420955-189512448.dng'
short-content: '대한의용생체공학회 우수포스터상 수상'
comments: true
---

정성연, 유지원 연구원이 2025년 대한의용생체공학회 추계학술대회에서 발표한 ‘LLM 기반 임상화학검사 결과보고서 자동 생성’으로 우수포스터상을 수상하였습니다🎊

![](/images/posts/202511/be759000-5b32-4e81-bc93-22a4bdcc9697.dng)
