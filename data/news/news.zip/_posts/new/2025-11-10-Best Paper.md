---
layout: post
title: '우수논문상 [Best Paper]'
date: 2025-11-10 06:33:01
featured-img: '/images/posts/202511/thumbnail_image-1762756382324-163364956.dng'
short-content: '대한의용생체공학회 우수논문상 수상'
comments: true
---

최예은 학생이 2025년 대한의용생체공학회 추계학술대회에서 발표한 ‘Multi-Variate Time Series Transformer 기반 패혈증 조기 예측 모델 개발’로 우수논문상을 수상하였습니다🎊

![](/images/posts/202511/1c1e5cde-3992-4d69-b715-365aa0fe7808.dng)
