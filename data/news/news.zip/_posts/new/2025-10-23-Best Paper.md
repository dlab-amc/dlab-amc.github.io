---
layout: post
title: '우수논문상 [Best Paper]'
date: 2025-10-23 00:00:00
featured-img: '/images/posts/202510/thumbnail_image-1767336000154-117621290.png'
short-content: 'CICS'25 우수 논문상 수상'
comments: true
---

진재욱 학생 (박사과정)이 CICS'25에서 발표한 'PubMedBERT-Deep Neural Network 융합모델을 이용한 수술 후 장기 재원 환자 예측'로 우수논문상을 수상하였습니다🎊


![](/images/posts/202510/a226ce59-6dd6-4f5d-ba0c-c20c4d252f6f.png) 
