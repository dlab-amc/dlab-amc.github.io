---
layout: post
title: '우수 논문상 [Best Paper]'
date: 2025-08-13 05:11:46
featured-img: '/images/posts/202508/thumbnail_image-1755061906199-585248788.png'
short-content: '대한전기학회 우수 논문상 수상'
comments: true
---

진재욱 학생이 2025년 대한전기학회 하계학술대회에서 발표한 '수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발'으로 우수 논문상을 수상하였습니다🎊


![](/images/posts/202508/90cd4f34-ff20-4398-b8d3-55eaeb854046.png)

