---
layout: post
title: "Scientific Reports 논문 게재 [New paper published]"
date: 2026-09-15 00:00:00
permalink: /2026/09/15/new-paper-published-85845e.html
featured-img: '/images/posts/202609/thumbnail_image-1789445661191-888913355.png'
short-content: "Scientific Reports 논문 게재"
views: 0
comments: true
---

왕창원 교수님 (순천향대), 신항식 교수님의 ‘Assessing pre-frailty in the elderly using explainable AI’ 논문이 Nature Scientific Reports
에 게재되었습니다!🎊

Scientific Reports의 IF(Impact Factor)는 4.9입니다.

논문 게재를 축하드립니다🥳🎉

![]({{ '/images/posts/202609/7519b61c-feb4-48c8-8683-a5b5442ad271.png' | relative_url }})
