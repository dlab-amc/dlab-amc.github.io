---
layout: post
title: '우수 논문상 [Best Paper]'
date: 2025-07-18 06:42:49
featured-img: '/images/posts/202507/thumbnail_image-1755067370184-507859673.png'
short-content: '대한전기학회 우수 논문상 수상'
comments: true
---

진재욱 학생이 2025년 대한전기학회 하계학술대회에서 발표한 '수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발'으로 우수 논문상을 수상하였습니다🎊


![](/images/posts/202507/4ed50a85-d9d5-4dc4-b471-73f0d1ee9c45.png)
