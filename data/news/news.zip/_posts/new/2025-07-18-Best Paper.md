---
layout: post
title: '우수 논문상 [Best Paper]'
date: 2025-07-18 06:01:32
featured-img: '/images/posts/202507/thumbnail_image-1755064892800-873889895.png'
short-content: '대한전기학회 우수 논문상 수상'
comments: true
---

진재욱 학생이 2025년 대한전기학회 하계학술대회에서 발표한 '수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발'으로 우수 논문상을 수상하였습니다🎊

![](/images/posts/202507/92440c9d-7eda-42d3-83a7-ceace4887f46.png)

