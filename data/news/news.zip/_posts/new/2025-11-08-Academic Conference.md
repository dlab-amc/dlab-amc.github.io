---
layout: post
title: '학술대회 [Academic Conference]'
date: 2025-11-08 06:32:21
featured-img: '/images/posts/202511/thumbnail_image-1762756341802-731999031.png'
short-content: '2025 대한의용생체공학회 추계학술대회 참석'
comments: true
---

1월 6일부터 8일까지 인제대학교에서 열린 2025 대한의용생체공학회 추계학술대회에 참석하였습니다.

구연 발표 (최예은)와 포스터 발표 (진재욱, 한유진, 김영돈, 유지원, 이건, 정성연)를 하여 학술대회에서 우리 팀의 성과를 발표하는 시간을 가졌습니다🤓📝

![](/images/posts/202511/30160467-bdb2-4a56-95b8-413ae37d94ef.dng)![](/images/posts/202511/21220241-cb8d-40bb-9516-eabb9d18f5b0.dng)
