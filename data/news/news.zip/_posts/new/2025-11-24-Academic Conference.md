---
layout: post
title: "학술대회 [Academic Conference]"
date: 2025-11-24 00:00:00
featured-img: '/images/posts/202511/thumbnail_image-1764642707100-113481640.png'
short-content: "2025 대한의료정보학회 추계학술대회 참석"
comments: true
---

11월 22일부터 24일까지 송도 컨벤시아에서 열린 2025년 대한의료정보학회 추계학술대회에 참석하였습니다.

의료정보학회에서 의료정보학, LLM 및 Agentic AI 관련 강의를 들으며 전문성을 확장할 수 있는 유익한 시간을 가졌습니다🤓📝![](/images/posts/202511/aa72a8b0-b0c2-49d8-a91f-bb44ca23cfdd.png)
