--- 
layout: member 
title: Yeonjoo Shin 
member:
  name_eng: 'Yeonjoo Shin'
  degree: 'M.S.'
  profile_image: '/images/members/신연주_0.jpg'
  hover_image: '/images/members/egg_신연주.PNG'
  role: 'Researcher'
  profile_description: |
    [E-mail](mailto:shinyeonjoo98@gmail.com)
    Research Areas : Machine learning, Natural Language Processing, Multi-Modal
  contents: |
    
    
--- 
