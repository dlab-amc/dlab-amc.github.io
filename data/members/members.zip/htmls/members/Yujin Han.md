--- 
layout: member 
title: Yujin Han 
member:
  name_eng: 'Yujin Han'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1760500606315-672307507.jpg'
  hover_image: '/images/members/egg_한유진.jpg'
  role: 'Master Course'
  profile_description: |
    [E-mail](mailto:yujin.han.ds@gmail.com)
    Research Areas : Statistics, Machine learning
  contents: |
    ## Journal
    
    -  박예진, 엄정민, 홍수빈, 한유진, 김재희. 직장 네트워크 데이터에 대한 통계적 ERGM 분석. 응용통계연구. 35(4), 527-541. (2022).
    
    -  한유진, 김재희. TERGM 과 SAOM 비교: 학생 네트워크 데이터의 통계적 분석. 응용통계연구. 36(1), 1-19. (2023).
    
    -  한유진, 김준식, 김재희. 뇌전증 환자의 MEG 데이터에 대한 분류를 위한 인공신경망 적용 연구. 응용통계연구. 37(2), 139-155. (2024).
    
    - 한유진, 정천기, 김재희. 위상학적 데이터 분석과 인공 신경망을 이용한 뇌전증 MEG 데이터 분류 연구. 응용통계연구. 38(2), 189-204. (2025).
    
    ## Conference
    
    <!-- e428df87-b2b6-49b4-9d24-ac5b4fdfeb4a -->
    - 김영돈, 임하민, 류가연, 한유진, 신항식. 단일 깊이측정 카메라를 활용한 실시간 상지 관절 가동범위 측정 방법 개발. 2024 대한전기학회 제55회 하계학술대회. 2024. 7. 10-13; 제주국제켄벤션센터, 부영호텔&리조트; 2024.
    
    <!-- 8bf5ada9-036e-45ea-8e1b-88061cc5e1d0 -->
    - 류가연, 한유진, 김영돈, 신항식. 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석. 대한의용생체공학회 2024년 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- bc9325f2-deac-4a51-9d2f-aaf8cade661b -->
    - 한유진, 신항식. 다기관 Radiomic Tractometry 데이터 편차 보정을 위한 Harmonization 파이프라인. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- 2ba08e29-f55b-4c5c-9cf2-8f9991f04638 -->
    - 한유진, 주성우, 신항식. Radiomic Tractometry 기반 조현병 환자군 분류 인공지능 모델 개발. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    
    
    <!-- 2f8c8ab8-403f-4529-90ba-b413f389e033 -->
    - Han Y, Joo SW, Shin H. Evaluating Feature Selection Methods for Radiomic Tractometry in Schizophrenia. The 47th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC). 2025 Jul 14-17; Copenhagen, Denmark; 2025.
    
    <!-- 214ed0bc-e135-4f8e-b4bf-db4de9a273db -->
    - 김영돈, 한유진, 신항식. 수면 분석 알고리즘 평가를 위한 다기관 수면다원검사 데이터 세트 구축. 대한전기학회 제56회 하계학술대회. 2025. 7. 16-19; 부산 벡스코; 2025.
    
    <!-- 2894dca4-39fd-49cc-a53f-ac43f94e66be -->
    - 한유진, 신항식. Cox를 넘어: 비선형 임상 변수 해석에서 드러난 인공지능 기반 생존분석의 가능성. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 948579a2-5419-4714-a232-4ac161d42c63 -->
    - Han Y, Shin H, Won D, Yoon Y. Artificial Intelligence–Driven Preoperative Risk Stratification for Early Allograft Failure in Living Donor Liver Transplantation. 2026 ILTS Congress. 2026 May 6-9; GENEVA, SWITZERLAND; 2026.
    
    <!-- 0bd7ed03-073b-4f54-8e3c-efbead217078 -->
    - 한유진, 류가연, 김영돈, 신항식. 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 6757496c-84b9-4b4a-a3da-785e7e957188 -->
    - 김영돈, 한유진, 류가연, 이연진, 신항식. 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 49037bdf-5e2e-4e08-b226-ec1a5698f280 -->
    - Han Y, Shin H. Anomaly Detection-Based Hybrid Machine Learning for Predicting Early Allograft Failure in Living Donor Liver Transplantation. The 48th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC). 2026 Jul 26-30; Toronto, Canada; 2026.
    ## Award
    
    3.  2023 이브와 ICT멘토링 공모전 금상(과학기술정보통신부장관상), 과학기술정보통신부(주최), 정보통신기획평가원(주관), IT여성기업인협회(주관), 2023.12
    
    2.  대한의용생체공학회 추계 학술대회 우수 포스터 논문상(금상), 대한의용생체공학회, 2024.11
    
    1.  대한의용생체공학회 춘계 학술대회 최우수 포스터상, 대한의용생체공학회, 2025.05
    
    <!-- 6ca3ccd4-4fc1-4256-9b02-b1791eedce4e -->
    - 김영돈; 한유진; 류가연; 이연진; 신항식(Yeongdon Kim; Yujin Han; Gayeon Ryu; Yeonjin Lee; Hangsik Shin), 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발(Development of a Digital Tool for Supporting the Development and Evaluation of Polysomnography Devices), Domestic, 2026-05-09, RS-2023-00215716, 우수논문상, 대한의용생체공학회
    <!-- 4b92b947-c52a-4631-aa1e-eecad88284cb -->
    - 한유진; 류가연; 김영돈; 신항식(Yujin Han; Gayeon Ryu; Yeongdon Kim; Hangsik Shin), 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계(A Framework for Virtual Clinical Trial Reports for Sleep Analysis Algorithms), Domestic, 2026-05-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    <!-- 67a24a4a-f86d-4be9-82d7-b72d2d740b4c -->
    - 한유진(Yujin Han), Domestic, 2026-05-09, 2026 대한의용생체공학회 표창장, 한국의료기기안전정보원장
    <!-- cbdc3907-90f6-59c8-a5d0-304b0f237814 -->
    - 한유진; 신항식(Yujin Han; Hangsik Shin), 다기관 Radiomic Tractometry 데이터 편차 보정을 위한 Harmonization 파이프라인(Harmonization Pipeline for Correcting Data Discrepancies in Multicenter Radiomic), Domestic, 2025-05-09, RS-2023-00215716, 최우수포스터상, 대한의용생체공학회
    <!-- 48b4dd71-619c-5b88-ae98-9044469eea44 -->
    - 류가연; 한유진; 김영돈; 신항식(Gayeon Ryu; Yujin Han; Yeongdon Kim; Hangsik Shin), 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석(Bio-signals and result feature analysis to leverage public polysomnography database  integration), Domestic, 2024-11-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    ## Patent
    
    <!-- 44529fa4-e591-47bf-b088-15889379a27c -->
    - 신항식, 한유진. 다기관에서 수집된 데이터를 전처리하는 장치 및 방법. KR 10-2025-0140516, 2025. 9. 26.
    
    <!-- c6afaed1-66e1-4f24-96b3-3a3a323defbb -->
    - 신항식, 주성우, 이중선, 한유진. 뇌 질환 진단 장치 및 방법. KR 10-2025-0157997, 2025. 10. 28.
--- 
