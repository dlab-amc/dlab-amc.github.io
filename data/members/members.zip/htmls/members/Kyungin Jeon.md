--- 
layout: member 
title: Kyungin Jeon 
member:
  name_eng: 'Kyungin Jeon'
  degree: 'B.A.'
  profile_image: '/images/members/전경인_0.png'
  hover_image: '/images/members/egg_전경인.JPG'
  role: 'Administrative Assistant'
  profile_description: |
    [dls7522@gmail.com](dls7522@gmail.com)
  contents: |
    ## Duty
    
    1.  Management of National Research Agreement
    2.  Management of Research Budget & finance
    3.  Management of Researcher contract
    
    
--- 
