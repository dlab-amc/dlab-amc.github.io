--- 
layout: member 
title: Gayeon Ryu 
member:
  name_eng: 'Gayeon Ryu'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1767665532558-733347958.png'
  hover_image: '/images/members/egg_류가연.JPG'
  role: 'Master Course'
  profile_description: |
    Research Areas : Data analysis, Statistics, Signal analysis
    
    [E-mail](mailto:rgy90257823@gmail.com)
  contents: |
    ## Journal
    
    <!-- 6d8b5817-2a7b-4507-9d7f-21de5560f5a4 -->
    - Ryu G, Choi JM, Lee J, Seok HS, Shin H, Choi B. Analysis of Photoplethysmography-Based Surgical Pain Severity Assessment Markers. Journal of Electrical Engineering & Technology. 2024 Aug; 19(6):3665-3674; IF:1.6@2023JIF; 2021-0100, KCT0005840.
    
    <!-- a88dd95e-adb0-46cb-a2ae-ab50f1b56c45 -->
    - Lee J, Kwon O, Ryu G, Shin H, Pak H. Atrial Fibrillation Identification Using CNNs Based on Genomic Data. Journal of Electrical Engineering & Technology. 2024 Aug; 19(6):3645–3653; IF:1.6@2023JIF; RS-2022-00141473, KBN-2016-005, KBN-2020-083.
    
    <!-- 4df94230-b073-4e4c-9037-277fc44342b8 -->
    - Ryu G, Choi JM, Seok HS, Lee J, Lee E, Shin H, Choi B. Machine learning based quantitative pain assessment for the perioperative period. npj Digital Medicine. 2025 Jan; 8(1):53; IF:12.4@2023JIF; HR20C0026, HI22C1668, RS-2024-00335644.
    <!-- 75480fca-4d6e-4b0f-bef4-bd19409c4b34 -->
    - Kim T, Ryu G, Choi YE, Shin H. Medication-specific risk of atrial fibrillation in patients with coronary artery disease. Biomedical Engineering Letters. 2026 Jun; IF:3.4@2025JIF; RS-2024-00335644, 2024IP0021.
    ## Conference
    
    18.  Ga Yeon Ryu, Hyeon Seok Seok, Changwon Wang, Byung-Moon Choi, Jae Moon Choi, Hangsik Shin, "Comparison of Photoplethysmogram Feature for Intraoperative Pain and Postoperative Pain", Conference on Information and Control Systems 2022 (CICS), Pyeongchang, Korea (Oct. 2022)
    
    17.  Ga Yeon Ryu, Hyeon Seok Seok, Changwon Wang, Byung-Moon Choi, Jae Moon Choi, Hangsik Shin, "Photoplethysmogram Feature Analysis for Surgical Pain Assessment", KOSOMBE autumn conference, Incheon, Korea (Nov. 2022)
    
    16.  Hyeon Seok Seok, Ga Yeon Ryu, Hangsik Shin, Jae Moon Choi, Byung-Moon Choi, "Development of an artificial intelligence model for both intra- and post-operative pain assessment", The Korean Society for Anesthetic Pharmacology (KSAP), Seoul, Korea (Apr. 2023)
    
    15.  Ga Yeon Ryu, Hyeon Seok Seok, Hangsik Shin, Byung-Moon Choi, Jae Moon Choi, "Development of photoplethysmogram based feature for intra- and post-operative pain", KOSOMBE spring conference, Daegu, Korea (May. 2023)
    
    12.  Gayeon Ryu, Hyeon Seok Seok, Byung-Moon Choi, Jae Moon Choi, Hangsik Shin, "Analysis of Surgical Pain Severity Assessment Feature based on Photoplethysmogram", The 54th KIEE Summer Conference, Pyeongchang, Korea (Jul. 2023)
    
    <!-- 35fe7426-b8bf-4fcb-a7f2-b8db79a47148 -->
    - Seok HS, Ryu G, Choi JM, Choi B, Shin H. Arrival Times of Maximum Pain and Pain Suppression After Acute Pain Stimulation in Surgical Procedure. 45th Annual International Conference of the IEEE Engineering in Medicine and Biology Society. 2023 Jul 24-27; Sydney International Convention Centre (ICC); 2023.
    
    11.  Gayeon Ryu, Hyeon Seok Seok, Byung-Moon Choi, Jae Moon Choi, Hangsik Shin, "Photoplethysmogram based on Surgical Pain Severity Assessment Feature Analysis", KOSOMBE autumn conference, Seoul, Korea (Nov. 2023)
    
    <!-- eca439f7-9ff8-406a-9895-2437c3a9b420 -->
    - Ryu G, Seok HS, Shin H. Ectopic Beat Correction Strategies for Accurate Heart Rate Variability Analysis. IEEE EMBS International Conference on Data Science and Engineering in Healthcare, Medicine & Biology. 2023 Dec 7-9; Portomaso, St. Julians, Malta; 2023.
    
    <!-- 17bf2ac9-95d2-4b28-af8b-f9b5bab02212 -->
    - 류가연, 석현석, 최병문, 최재문, 신항식. 광용적맥파 기반 수술후 통증 중증도 평가지표 분석. 2024년 제63회 대한의용생체공학회 춘계 학술대회. 2024. 5. 9-11; 강원도 원주 연세대학교 미래캠퍼스 컨버전스홀; 2024.
    
    8.  Y.Kim, G.Y Ryu, H.H Jeong, J. H. Oh, M. Kim, S. A. Park, H. L. Yang, "Development of interoprative blood transfusion prediction model", CARS 2024 Computer Assisted Radiology and Surgery, Barcelona, Spain (Jun. 2024)
    
    <!-- e428df87-b2b6-49b4-9d24-ac5b4fdfeb4a -->
    - 김영돈, 임하민, 류가연, 한유진, 신항식. 단일 깊이측정 카메라를 활용한 실시간 상지 관절 가동범위 측정 방법 개발. 2024 대한전기학회 제55회 하계학술대회. 2024. 7. 10-13; 제주국제켄벤션센터, 부영호텔&리조트; 2024.
    
    <!-- c0e967e7-4969-4ea0-a624-ff9f3c621cbe -->
    - 류가연, 최예은, 신항식. 광용적맥파 기반 혈관 나이 추정 모델의 평가. CICS’24 정보 및 제어 학술대회. 2024. 10. 23-26; 금호통영마리나리조트; 2024.
    <!-- 8bf5ada9-036e-45ea-8e1b-88061cc5e1d0 -->
    - 류가연, 한유진, 김영돈, 신항식. 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석. 대한의용생체공학회 2024년 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- f465d274-a2ed-447b-a17c-e9f8ade4cda7 -->
    - 류가연, 최예은, 신항식. 인구통계 특성 및 유관질환이 심방세동 발병에 미치는 영향. 2024년도 제 64회 대한의용생체공학회 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- ce676224-6524-494b-ac75-4af3b52d8fa9 -->
    - 류가연, 최예은, 신항식. 건강검진 데이터 기반 심방세동 예측 모델 개발. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- 64a5c206-ab29-4a1d-8778-2999a0bf4df7 -->
    - 김태현, 류가연, 최예은, 신항식. 관상동맥질환 치료제의 심방세동 발생에 대한 영향: 후향적 코호트 분석. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- b928a941-79da-4486-b9f0-02b3b6e86c9a -->
    - 석현석, 이건, 류가연, 신항식. 광용적맥파 기반 정신적 피로 평가 가능성 연구. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- e7f50914-9069-4843-a9e8-675b99ffc3a2 -->
    - 진재욱, 류가연, 심지훈, 신항식. PubMedBERT-Deep Neural Network 융합모델을 이용한 수술 후 장기 재원 환자 예측. CICS’25 정보 및 제어 학술대회. 2025. 10. 22-25; 고성 델피노리조트; 2025.
    
    <!-- 7d64f21d-e836-4a19-adad-39e7a05d212d -->
    - 진재욱, 류가연, 심지훈, 신항식. 수술 후 재원 기간 예측을 위한 BioclinicalBERT-DNN 융합 모델 개발. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 8cd9638b-94ac-4ee4-9283-6266d38535cb -->
    - Jin J, Ryu G, Sim J, Shin H. PubMedBERT-Based Terminology Mapping for Surgical Procedure Types. The 7th International Conference on Advanced Bioinformatics and Biomedical Engineering. 2025 Dec 21-23; Tokyo, Japan; 2025.
    
    <!-- 0bd7ed03-073b-4f54-8e3c-efbead217078 -->
    - 한유진, 류가연, 김영돈, 신항식. 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 6757496c-84b9-4b4a-a3da-785e7e957188 -->
    - 김영돈, 한유진, 류가연, 이연진, 신항식. 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 611557ad-9346-42f9-a88b-bcda04e67cd4 -->
    - 진재욱, 류가연, 심지훈, 신항식. 수술 후 재원 기간 예측을 위한 머신러닝 모델 개발 및 다기관 외부 검증. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 93d0f6a3-536d-46ce-a41d-c29557550ecb -->
    - 류가연, 최예은, 신항식. 건강검진 스크리닝을 위한 심방세동 위험 예측 모델 개발. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    ## Award
    
    5.  Paper of the Year Award, AMIST 종합학술대회, Korea (Nov. 2022)
    
    4.  Best Abstract Awards, Spring Conference, Korean Society for Anesthetic Pharmacology, Korea (Apr. 2023)
    
    3.  2024년 정보 및 제어 학술대회 우수논문상, 대한전기학회, Korea (Oct. 2024)
    
    1.  대한의용생체공학회 2024 추계학술대회 우수 포스터 논문상, 대한의용생체공학회, Korea (Nov. 2024)
    
    2.  대한의용생체공학회 2024년 추계학술대회 우수논문상, 대한의용생체공학회, Korea (Nov. 2024)
    
    <!-- f2b46502-eba0-4b55-b98d-1b1f088f9869 -->
    - 진재욱; 류가연; 심지훈; 신항식(Jaewook Jin; Gayeon Ryu; Ji-Hoon Sim; Hangsik Shin), PubMedBERT-Deep Neural Network 융합모델을 이용한 수술 후 장기 재원 환자 예측(Prolonged Length of Stay Prediction with PubMedBERT-Deep Neural Network Fusion Model), Domestic, 2025-10-23, RS-2024-00423853, 우수논문상, 대한전기학회
    <!-- f2282795-e0d3-4dcb-93e0-a04a2aef2032 -->
    - 진재욱; 류가연; 심지훈; 신항식(Jaewook Jin; Gayeon Ryu; Ji-Hoon Sim; Hangsik Shin), 수술 후 재원 기간 예측을 위한 BioclinicalBERT-DNN 융합 모델 개발(Development of a BioclinicalBERT-Deep Neural Network Fusion Model for Predicting Postoperative Length of Stay), Domestic, 2025-11-08, RS-2024-00423853, 최우수포스터상, 대한의용생체공학회
    <!-- 6ca3ccd4-4fc1-4256-9b02-b1791eedce4e -->
    - 김영돈; 한유진; 류가연; 이연진; 신항식(Yeongdon Kim; Yujin Han; Gayeon Ryu; Yeonjin Lee; Hangsik Shin), 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발(Development of a Digital Tool for Supporting the Development and Evaluation of Polysomnography Devices), Domestic, 2026-05-09, RS-2023-00215716, 우수논문상, 대한의용생체공학회
    <!-- b4b37a0b-317c-4211-bbec-f47a63ab29cf -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 건강검진 스크리닝을 위한 심방세동 위험 예측 모델 개발(Development of an Atrial Fibrillation Risk Prediction Model for Health Screening), Domestic, 2026-05-09, RS-2023-0021571; 2024IP0021, 우수포스터상, 대한의용생체공학회
    <!-- 4b92b947-c52a-4631-aa1e-eecad88284cb -->
    - 한유진; 류가연; 김영돈; 신항식(Yujin Han; Gayeon Ryu; Yeongdon Kim; Hangsik Shin), 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계(A Framework for Virtual Clinical Trial Reports for Sleep Analysis Algorithms), Domestic, 2026-05-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    <!-- 6ef31ff6-7f4f-41e4-957c-210113d5a3ef -->
    - 류가연(Gayeon Ryu), Domestic, 2026-05-09, 2026 대한의용생체공학회 표창장, 한국의료기기안전정보원장
    <!-- bac6622f-7f90-5f5c-83cd-e07d87fb3a4e -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 인구통계 특성 및 유관질환이 심방세동 발병에 미치는 영향(The Impact of Demographic Characteristics and Comorbidities on the Incidence of Atrial Fibrillation), Domestic, 2024-11-09, RS-2022-00141473; 2024IP0021, 우수논문상, 대한의용생체공학회
    <!-- 48b4dd71-619c-5b88-ae98-9044469eea44 -->
    - 류가연; 한유진; 김영돈; 신항식(Gayeon Ryu; Yujin Han; Yeongdon Kim; Hangsik Shin), 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석(Bio-signals and result feature analysis to leverage public polysomnography database  integration), Domestic, 2024-11-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    <!-- 3c29fe36-bc32-5aa7-aefc-da20c5001b08 -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 광용적맥파 기반 혈관 나이 추정 모델의 평가(Evaluation of Photoplethysmogram-based Vascular Age Estimation Models), Domestic, 2024-10-23, RS-2024-00423853, 우수논문상, 대한전기학회 정보 및 제어 부문회
    <!-- e3eea7c6-89ab-5301-9628-df51cf927e6a -->
    - 석현석; 신항식; 최병문; 류가연; 최재문(Hyeon Seok Seok; Hangsik Shin; Byungmoon Choi; Gayeon Ryu; Jae Moon Choi), Development of an artificial intelligence model for both intra- and post-operative pain assessment, Domestic, 2023-04-15, 우수초록상, 대한마취약리학회
    ## Patent
    
    <!-- 3f037504-428d-406c-9c76-7d0fde04eb4c -->
    - 신항식, 최병문, 최재문, 류가연. 통증평가모델 생성 장치, 통증평가모델 생성 방법 및 이를 수행하는 프로그램이 저장된 기록 매체. KR 10-2024-0053680, 2024. 4. 22.
    
--- 
