--- 
layout: member 
title: Minso Kim 
member:
  name_eng: 'Minso Kim'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1760350593199-724054674.jpg'
  hover_image: '/data/members/images/members/hover_image-1760350430320-394474140.jpg'
  role: 'Researcher'
  profile_description: |
    [E-mail](mailto:rlaalsth1998@gmail.com)
    Research Areas : Bioinformatics, Medical AI, Data Analysis
  contents: |
    
--- 
