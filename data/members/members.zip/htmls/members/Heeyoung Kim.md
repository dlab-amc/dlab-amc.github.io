--- 
layout: member 
title: Heeyoung Kim 
member:
  name_eng: 'Heeyoung Kim'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1769998383906-13603753.png'
  hover_image: '/data/members/images/members/hover_image-1769998383921-906528921.jpg'
  role: 'Web Developer'
  profile_description: |
    [E-mail](mailto:talent8661@gmail.com)
    Interesting Areas : Web Back-end, Web Front-end, Mobile Application Development
  contents: |
    ## Conference
    
    1.  김희영, 여지은, 윤소원, 홍헬렌. 시퀀스-투-시퀀스 모델의 어텐션 메커니즘 유무에 따른 성능 차이. 2023 한국멀티미디어학회. 2023. 11. 17-18; 계명대학교; 2023.
--- 
