--- 
layout: member 
title: Sungyeon Chung 
member:
  name_eng: 'Sungyeon Chung'
  degree: 'B.Eng.'
  profile_image: '/data/members/images/members/profile_image-1754265859372-801784815.jpg'
  hover_image: '/data/members/images/members/hover_image-1754265859380-619228132.jpg'
  role: 'Research Intern'
  profile_description: |
    [sungyeon.ch8@gmail.com](mailto:sungyeon.ch8@gmail.com)
    Research Areas : Biosignal analysis, Medical AI
  contents: |
    
--- 
