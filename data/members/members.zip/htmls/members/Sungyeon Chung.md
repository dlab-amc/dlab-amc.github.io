--- 
layout: member 
title: Sungyeon Chung 
member:
  name_eng: 'Sungyeon Chung'
  degree: 'B.Eng.'
  profile_image: '/data/members/images/members/profile_image-1754265859372-801784815.jpg'
  hover_image: '/data/members/images/members/hover_image-1754265859380-619228132.jpg'
  role: 'Researcher'
  profile_description: |
    [E-mail](mailto:sungyeon.ch8@gmail.com)
    Research Areas : Biosignal analysis, Medical AI
  contents: |
    
    
    ## Conference
    <!-- 953bc51d-de68-43ee-a4a5-cc10a73d427a -->
    - 정성연, 유지원, 신항식. LLM 기반 임상화학검사 결과보고서 자동 생성. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    ## Award
    <!-- 34dc931e-4d40-4ecd-be98-ec618d6339d4 -->
    - 정성연; 유지원; 신항식(Sungyeon Chung; Jiwon You; Hangsik Shin), LLM 기반 임상화학검사 결과보고서 자동 생성(Clinical Chemistry Report Generation with a Large Language Model), Domestic, 2025-11-08, 2025IP0002; 2024IP0025; RS-2024-00335644, 우수포스터상, 대한의용생체공학회
--- 
