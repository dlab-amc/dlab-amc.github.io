--- 
layout: member 
title: Jaewook Jin 
member:
  name_eng: 'Jaewook Jin'
  degree: 'M.S.'
  profile_image: '/data/members/images/members/profile_image-1760920174001-120489742.jpg'
  hover_image: '/images/members/egg_진재욱.jpeg'
  role: 'Ph.D. Course'
  profile_description: |
    Research Areas : Biosignal analysis, Biomedical engineering
    
    [E-mail](mailto:realwooook@gmail.com)
  contents: |
    ## Journal
    
    1.  Jaewook Jin, Kahye Kim, KunHo Lee, Jeong-Woo Seo, Jaeuk U. Kim, "Association Between Cognitive Function and the Autonomic Nervous System by Photoplethysmography", Bioengineering 2024, 11(11), 1099, 2024
    
    ## Award
    
    <!-- 1882265d-f7bd-4226-a005-3881b0fd3648 -->
    - 진재욱; 신항식(Jaewook Jin; Hangsik Shin), 수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발(Development of artificial intelligence for predicting postoperative pain based on preoperative biosignal), Domestic, 2025-07-18, RS-2024-00423853; RS-2022-00141473, 2025 대한전기학회 하계학술대회 논문상, 대한전기학회
    <!-- f2b46502-eba0-4b55-b98d-1b1f088f9869 -->
    - 진재욱; 류가연; 심지훈; 신항식(Jaewook Jin; Gayeon Ryu; Ji-Hoon Sim; Hangsik Shin), PubMedBERT-Deep Neural Network 융합모델을 이용한 수술 후 장기 재원 환자 예측(Prolonged Length of Stay Prediction with PubMedBERT-Deep Neural Network Fusion Model), Domestic, 2025-10-23, RS-2024-00423853, 우수논문상, 대한전기학회
    <!-- f2282795-e0d3-4dcb-93e0-a04a2aef2032 -->
    - 진재욱; 류가연; 심지훈; 신항식(Jaewook Jin; Gayeon Ryu; Ji-Hoon Sim; Hangsik Shin), 수술 후 재원 기간 예측을 위한 BioclinicalBERT-DNN 융합 모델 개발(Development of a BioclinicalBERT-Deep Neural Network Fusion Model for Predicting Postoperative Length of Stay), Domestic, 2025-11-08, RS-2024-00423853, 최우수포스터상, 대한의용생체공학회
    <!-- 08ca5407-b74a-405a-8314-43f496d08c68 -->
    - 진재욱; 신항식(Jaewook Jin; Hangsik Shin), 수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발(Development of artificial intelligence for predicting postoperative pain based on preoperative biosignal), Domestic, 2025-12-12, RS-2024-00423853; RS-2022-00141473, 2025 대한전기학회 학술대회 우수논문상, 한국수력원자력(주)
    ## Conference
    
    <!-- 8540829d-f74d-46b9-964b-55c3d4497911 -->
    - 진재욱, 신항식. 수술 전 스트레스 평가를 통한 수술 후 통증 예측. 2025대한의용생체공학회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- 4f2e1e24-4da0-44dc-9d7b-b3de65087e47 -->
    - 진재욱, 신항식. 수술 전 생체신호 기반 수술 후 통증 예측 인공지능 모델 개발. 대한전기학회 제56회 하계학술대회. 2025. 7. 16-19; 부산 벡스코; 2025.
    
    <!-- e7f50914-9069-4843-a9e8-675b99ffc3a2 -->
    - 진재욱, 류가연, 심지훈, 신항식. PubMedBERT-Deep Neural Network 융합모델을 이용한 수술 후 장기 재원 환자 예측. CICS’25 정보 및 제어 학술대회. 2025. 10. 22-25; 고성 델피노리조트; 2025.
    
    <!-- 7d64f21d-e836-4a19-adad-39e7a05d212d -->
    - 진재욱, 류가연, 심지훈, 신항식. 수술 후 재원 기간 예측을 위한 BioclinicalBERT-DNN 융합 모델 개발. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 8cd9638b-94ac-4ee4-9283-6266d38535cb -->
    - Jin J, Ryu G, Sim J, Shin H. PubMedBERT-Based Terminology Mapping for Surgical Procedure Types. The 7th International Conference on Advanced Bioinformatics and Biomedical Engineering. 2025 Dec 21-23; Tokyo, Japan; 2025.
    
    <!-- 611557ad-9346-42f9-a88b-bcda04e67cd4 -->
    - 진재욱, 류가연, 심지훈, 신항식. 수술 후 재원 기간 예측을 위한 머신러닝 모델 개발 및 다기관 외부 검증. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
--- 
