--- 
layout: member 
title: Jaewook Jin 
member:
  name_eng: 'Jaewook Jin'
  degree: 'M.S.'
  profile_image: '/images/members/진재욱.jpg'
  hover_image: '/images/members/egg_진재욱.jpeg'
  role: 'Ph.D. Course'
  profile_description: |
    [realwooook@gmail.com](realwooook@gmail.com)
    Research Areas : Biosignal analysis, Biomedical engineering
  contents: |
    ## Journal
    
    1.  Jaewook Jin, Kahye Kim, KunHo Lee, Jeong-Woo Seo, Jaeuk U. Kim, "Association Between Cognitive Function and the Autonomic Nervous System by Photoplethysmography", Bioengineering 2024, 11(11), 1099, 2024
--- 
