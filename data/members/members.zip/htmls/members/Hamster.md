---
layout: member
title: hamster
member:
  name_eng: 'hamster'
  degree: 'cute'
  profile_image: '/data/members/images/members/profile_image-1750661628784-269033741.png'
  hover_image: '/data/members/images/members/hover_image-1750661628784-662560797.png'
  role: 'cute'
  profile_description: |
    hrhrh
  contents: |
    ㅎg
---
