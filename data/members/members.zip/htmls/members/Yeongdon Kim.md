--- 
layout: member 
title: Yeongdon Kim 
member:
  name_eng: 'Yeongdon Kim'
  degree: 'M.S.'
  profile_image: '/images/members/김영돈.jpg'
  hover_image: '/data/members/images/members/hover_image-1772620621202-249163042.jpg'
  role: 'Researcher'
  profile_description: |
    [E-mail](mailto:kyd5022@naver.com)
    Research Areas : Agentic AI, Medical AI, Digital Healthcare
  contents: |
    ## Skills
    
    Python,Kotlin,C/C++,Torch,TensorFlow
    
    ## Project
    
    1.  2021-02 ~ 2021-09 흰개미탐지모델 (하이테크)
    1\. 목조 문화제 보호를 위한 흰개미 탐지 모델 구성
    2\. 흰개미 데이터 크롤링(구글) 및 직접 촬영한 흰개미 데이터셋을 통해 Yolo v4모델 학습 및 인퍼런스 작업(라즈베리 파이)
    
    2.  2021-02 ~ 2021-09 문화제 기울기를 통한 위험 경보 시스템 (하이테크)
    1\. 문화제 보호를 위한 기울기 분석 및 예보
    2\. 문화제 건물에 부착된 기울기 센서값을 데이터베이스에 저장 및 분석
    3\. LSTM모델을 사용한 기울기 예측
    
    3.  2022-06 ~ 2022-11 고령자 행동인식 모델 개발 (강원대학교, 지오비전)
    1\. 엣지컴퓨팅에 들어가는 경량화 모델을 통해 고령자 행인식모델 개발
    2\. YOLOX-nano, ONNX, TFLite
    3\. 표정인식, 행동인식 Pretrained 모델을 안드로이드에서 적용 가능하도록 경량화작업 진행
    
    4.  2022-06 ~ 2022-11 고려대 병원 정신병동 스마트CCTV 작업 (지오비전, 고려대학교 병원)
    1\. 정신병동 환자구분, 환자 행동분석을 통해 스마트병동 구축 작업
    2\. PoseC3D, MMDetecion을 사용하여 환자의 행동 분석
    3\. 공공데이터 전처리 작업 및 모델 학습 준비 진행
    
    ## Award
    
    4.  강원 애니 데이터톤 우수상, 강원정보문화진흥원, 2022.01
    
    3.  AI Hub 학습데이터 활용 사업화 아이디어 해커톤 장려상, 한국스마트미디어학회, 2022.04
    
    2.  강원 정밀의료 빅데이터 해커톤 최우수상, 강원정밀의료사업단, 2022.12
    
    1.  대한의용생체공학회 추계 학술대회 우수 포스터 논문상(금상), 대한의용생체공학회, 2024.11
    
    <!-- 6ca3ccd4-4fc1-4256-9b02-b1791eedce4e -->
    - 김영돈; 한유진; 류가연; 이연진; 신항식(Yeongdon Kim; Yujin Han; Gayeon Ryu; Yeonjin Lee; Hangsik Shin), 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발(Development of a Digital Tool for Supporting the Development and Evaluation of Polysomnography Devices), Domestic, 2026-05-09, RS-2023-00215716, 우수논문상, 대한의용생체공학회
    <!-- 4b92b947-c52a-4631-aa1e-eecad88284cb -->
    - 한유진; 류가연; 김영돈; 신항식(Yujin Han; Gayeon Ryu; Yeongdon Kim; Hangsik Shin), 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계(A Framework for Virtual Clinical Trial Reports for Sleep Analysis Algorithms), Domestic, 2026-05-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    <!-- 48b4dd71-619c-5b88-ae98-9044469eea44 -->
    - 류가연; 한유진; 김영돈; 신항식(Gayeon Ryu; Yujin Han; Yeongdon Kim; Hangsik Shin), 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석(Bio-signals and result feature analysis to leverage public polysomnography database  integration), Domestic, 2024-11-09, RS-2023-00215716, 우수포스터상, 대한의용생체공학회
    ## Conference
    
    <!-- e428df87-b2b6-49b4-9d24-ac5b4fdfeb4a -->
    - 김영돈, 임하민, 류가연, 한유진, 신항식. 단일 깊이측정 카메라를 활용한 실시간 상지 관절 가동범위 측정 방법 개발. 2024 대한전기학회 제55회 하계학술대회. 2024. 7. 10-13; 제주국제켄벤션센터, 부영호텔&리조트; 2024.
    
    <!-- 8bf5ada9-036e-45ea-8e1b-88061cc5e1d0 -->
    - 류가연, 한유진, 김영돈, 신항식. 공개 수면다원검사 데이터베이스 통합 활용을 위한 생체신호 및 결과 변수 분석. 대한의용생체공학회 2024년 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- 214ed0bc-e135-4f8e-b4bf-db4de9a273db -->
    - 김영돈, 한유진, 신항식. 수면 분석 알고리즘 평가를 위한 다기관 수면다원검사 데이터 세트 구축. 대한전기학회 제56회 하계학술대회. 2025. 7. 16-19; 부산 벡스코; 2025.
    
    <!-- 3b6e71b3-7c19-4e21-8657-4f4a36e86f09 -->
    - 김영돈, 신항식. 대규모 공개 수면다원검사(PSG) 데이터셋을 활용한 파운데이션 모델 개발. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 0bd7ed03-073b-4f54-8e3c-efbead217078 -->
    - 한유진, 류가연, 김영돈, 신항식. 수면 의료기기 알고리즘 가상 임상시험 결과보고서 생성 프레임워크 설계. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 6757496c-84b9-4b4a-a3da-785e7e957188 -->
    - 김영돈, 한유진, 류가연, 이연진, 신항식. 수면다원검사기기 개발 및 평가 지원을 위한 디지털도구 개발. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
--- 
