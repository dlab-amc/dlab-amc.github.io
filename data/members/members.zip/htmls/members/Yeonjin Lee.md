--- 
layout: member 
title: Yeonjin Lee 
member:
  name_eng: 'Yeonjin Lee'
  degree: 'B.Sc'
  profile_image: '/images/members/이연진_0.png'
  hover_image: '/data/members/images/members/hover_image-1750746721518-353561026.png'
  role: 'Web Developer'
  profile_description: |
    [thisisyjin@gmail.com](mailto:thisisyjin@gmail.com)
    Interesting Areas : Web Application Development, Product Development
  contents: |
    # Deploy Test
    - Test 123
--- 
