--- 
layout: member 
title: Jangwon Seong 
member:
  name_eng: 'Jangwon Seong'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1753751765534-308066738.jpg'
  hover_image: '/data/members/images/members/hover_image-1753751765544-542049330.jpg'
  role: 'Web Developer'
  profile_description: |
    [nowgn02@gmail.com](nowgn02@gmail.com)
  contents: |
    
--- 
