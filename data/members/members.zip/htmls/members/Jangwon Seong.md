--- 
layout: member 
title: Jangwon Seong 
member:
  name_eng: 'Jangwon Seong'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1753764975368-745258052.jpg'
  hover_image: '/data/members/images/members/hover_image-1753764975378-690029088.jpg'
  role: 'Web Developer'
  profile_description: |
    [nowgn02@gmail.com](mailto:nowgn02@gmail.com)
    Interesting Areas : IoT, Back-End
  contents: |
    
--- 
