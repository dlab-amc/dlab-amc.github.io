--- 
layout: member 
title: Daeyeop Kim 
member:
  name_eng: 'Daeyeop Kim'
  degree: 'B.Sc.'
  profile_image: '/data/members/images/members/profile_image-1767340558028-843374147.jpg'
  hover_image: '/data/members/images/members/hover_image-1767340558028-880212251.PNG'
  role: 'Research Intern'
  profile_description: |
    [E-mail](mailto:daeyeopkim2@gmail.com)
    Research Areas : Biosignal analysis, Medical AI, Digital Healthcare
  contents: |
    
--- 
