--- 
layout: member 
title: TEST 
member:
  name_eng: 'TEST'
  degree: 'B.Sc'
  profile_image: '/data/members/images/members/profile_image-1750821813121-223260685.png'
  hover_image: '/data/members/images/members/hover_image-1750821813122-534769281.png'
  role: 'Researcher'
  profile_description: |
    테스트 멤버 입니다.
  contents: |
    ## 성과
    - 성과 1
    - 성과 2
    
    
    ## 수상
    - 수상 1
    - 수상 2
--- 
