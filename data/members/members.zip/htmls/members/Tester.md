--- 
layout: member 
title: Tester 
member:
  name_eng: 'Tester'
  degree: 'B.Sc'
  profile_image: '/data/members/images/members/profile_image-1755060257626-715683834.png'
  hover_image: '/data/members/images/members/hover_image-1755060257626-539054364.png'
  role: 'Researcher'
  profile_description: |
    123
  contents: |
    123123
--- 
