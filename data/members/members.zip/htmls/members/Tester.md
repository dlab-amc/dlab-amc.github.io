--- 
layout: member 
title: Tester 
member:
  name_eng: 'Tester'
  degree: 'B.Sc'
  profile_image: '/data/members/images/members/profile_image-1753322851120-270103489.png'
  hover_image: '/data/members/images/members/hover_image-1753322851121-925185108.png'
  role: 'Web Developer'
  profile_description: |
    test
  contents: |
    # Test
    1234
--- 
