--- 
layout: member 
title: Tester 
member:
  name_eng: 'Tester'
  degree: 'B.Sc'
  profile_image: '/data/members/images/members/profile_image-1752141165050-188921858.png'
  hover_image: '/data/members/images/members/hover_image-1752141165055-331322765.png'
  role: 'Researcher'
  profile_description: |
    Researcher Test
  contents: |
    
--- 
