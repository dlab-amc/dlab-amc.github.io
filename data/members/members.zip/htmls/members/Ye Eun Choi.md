--- 
layout: member 
title: Ye Eun Choi 
member:
  name_eng: 'Ye Eun Choi'
  degree: 'B.Sc.'
  profile_image: '/images/members/최예은.jpg'
  hover_image: '/data/members/images/members/hover_image-1754294732114-814035835.png'
  role: 'Master Course'
  profile_description: |
    [E-mail](mailto:yechoi.amc@gmail.com)
    Research Areas : Bioinformatics, Medical AI, Digital Healthcare
  contents: |
    ## Conference
    
    1. Muhyuk Kim, Hanbyul Song, Sung Joo Han, Ye Eun Choi, Hyebong Choi, Taejin Ahn. Differentially Expressed Genes Analysis of cancer developed by user centered web interface. "The 17th KOGO Winter Symposium," 한국유전체학회(KOGO), Seoul, Korea, Jan. 2021 - Conference poster
    
    2. Seonyeong Park, Mingu Lee, Ye-eun Choi, Hyebong Choi. 반응형 정보 시각화를 통한 정보 전달의 효율성: 코로나 19 감염증 확산과 방역 정책을 중심으로. "한국HCI학회 학술대회," 한국HCI학회, Seoul, Korea, Jan. 2021 - Conference paper
    
    <!-- 688ca5a0-8312-40d0-bb81-6ae6b13b9533 -->
    - Choi YE, Lee J, Seok HS, Shin H. Demographics and Comorbidities as an Atrial Fibrillation Risk Factor: a Retrospective Study in Koreans. EMBC 2024. 2024 Jul 15-19; Orlando, USA; 2024.
    
    <!-- c0e967e7-4969-4ea0-a624-ff9f3c621cbe -->
    - 류가연, 최예은, 신항식. 광용적맥파 기반 혈관 나이 추정 모델의 평가. CICS’24 정보 및 제어 학술대회. 2024. 10. 23-26; 금호통영마리나리조트; 2024.
    <!-- 1e67b630-51dd-4fe6-8733-7b2b92cc7c37 -->
    - 최예은, 신항식. 성인 패혈증 환자 사망 위험 분석: 인구통계 및 기저질환 연구. 2024년 대한의용생체공학회 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔, 대한민국; 2024.
    
    <!-- 238412a7-3471-4e8a-81e9-f1f105eef065 -->
    - 최예은, 신항식. 성인 패혈증 환자 생존율 분석: 인구통계 및 기저질환 연구. 2024년 대한의용생체공학회 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔, 대한민국; 2024.
    
    <!-- f465d274-a2ed-447b-a17c-e9f8ade4cda7 -->
    - 류가연, 최예은, 신항식. 인구통계 특성 및 유관질환이 심방세동 발병에 미치는 영향. 2024년도 제 64회 대한의용생체공학회 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- 3a9e8f81-52f2-470e-800c-e9f1acbd3558 -->
    - 정지영, 최예은, 신항식. 패혈증 조기 예측을 위한 머신러닝 모델 개발. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- 64a5c206-ab29-4a1d-8778-2999a0bf4df7 -->
    - 김태현, 류가연, 최예은, 신항식. 관상동맥질환 치료제의 심방세동 발생에 대한 영향: 후향적 코호트 분석. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- ce676224-6524-494b-ac75-4af3b52d8fa9 -->
    - 류가연, 최예은, 신항식. 건강검진 데이터 기반 심방세동 예측 모델 개발. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- ee5a24ad-4c4e-466e-9e12-079c56ef5830 -->
    - 최예은, 정지영, 신항식. 패혈증 사망 위험에 미치는 비만도와 나이 영향 분석. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- d44f19e2-f948-4020-b594-07ed6bf19b42 -->
    - Choi YE, Jung J, Shin H. Revisiting the Obesity Paradox in Septic Patients with Aging and Chronic Disease: A Retrospective Study in Korea. The 47th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC. 2025 Jul 14-17; Copenhagen, Denmark; 2025.
    
    <!-- 69e53ab6-1801-4751-b9e4-af764d75ce4c -->
    - 최예은, 신항식. 시계열 데이터의 결측치 대체 방법에 따른 Transformer 기반 패혈증 조기 예측 모델 성능 비교 평가. CICS’25 정보 및 제어 학술대회. 2025. 10. 22-25; 고성 델피노리조트; 2025.
    
    <!-- 1b6c1fd8-e248-4317-aa24-a30e0e900b3f -->
    - 최예은, 신항식. Multi-variate Time Series Transformer 기반 패혈증 조기 예측 모델 개발. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 92bae902-8be2-4c2d-9da6-5dc1164f9ba9 -->
    - 김민소, 이건, 최예은, 이우형, 홍광표, 신항식. 간내 담관암 림프절 전이 예측에서 MedGemma 1.5-4B의 활용 가능성 평가. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 16c444f7-bf32-4cfa-b971-e9dd9ab1b633 -->
    - 이건, 김민소, 최예은, 이우형, 홍광표, 신항식. 3D PET/CT 영상 및 임상 데이터 융합을 통한 딥러닝 기반 담관암 림프절 전이 예측. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 93d0f6a3-536d-46ce-a41d-c29557550ecb -->
    - 류가연, 최예은, 신항식. 건강검진 스크리닝을 위한 심방세동 위험 예측 모델 개발. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- a9a42c7d-3051-4d9a-a9e9-6e3c065b8a62 -->
    - Choi YE, Shin H. Transformer-Based Early Detection of Sepsis from Intensive Care Unit Multivariate Time Series Data. The 48th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (EMBC). 2026 Jul 26-30; Toronto, Canada; 2026.
    ## Award
    
    1. 2022 데이터 청년 캠퍼스 ‘우수 프로젝트 발표’ 장려상, 한국데이터산업진흥원(Korea Data Agency), Korea (Sep 2022)
    
    <!-- bdcfb609-561b-4759-a4ab-b2131804f634 -->
    - 최예은; 신항식(Ye Eun Choi; Hangsik Shin), Multi-variate Time Series Transformer 기반 패혈증 조기 예측 모델 개발(Early Sepsis Prediction Models with Multi-variate Time Series Transformer), Domestic, 2025-11-08, RS-2022-00141473; 2024IP0021, 우수논문상, 대한의용생체공학회
    <!-- 34089715-f049-42ae-a9da-1225439e002a -->
    - 이건; 김민소; 최예은; 이우형; 홍광표; 신항식(Geon Lee; Minso Kim; Ye Eun Choi; Woohyung Lee; Kwangpyo Hong; Hangsik Shin), 3D PET/CT 영상 및 임상 데이터 융합을 통한 딥러닝 기반 담관암 림프절 전이 예측(Deep Learning-based Prediction of Lymph Node Metastasis in Cholangiocarcinoma through Fusion of 3D PET/CT Imaging and Clinical Data), Domestic, 2026-05-09, RS-2020-KH088723, 최우수논문상, 대한의용생체공학회
    <!-- b4b37a0b-317c-4211-bbec-f47a63ab29cf -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 건강검진 스크리닝을 위한 심방세동 위험 예측 모델 개발(Development of an Atrial Fibrillation Risk Prediction Model for Health Screening), Domestic, 2026-05-09, RS-2023-0021571; 2024IP0021, 우수포스터상, 대한의용생체공학회
    <!-- 134eb3df-b4e6-437b-adbe-729566353474 -->
    - 김민소; 이건; 최예은; 이우형; 홍광표; 신항식(Minso Kim; Geon Lee; Ye Eun Choi; Woohyung Lee; Kwangpyo Hong; Hangsik Shin), 간내 담관암 림프절 전이 예측에서 MedGemma 1.5-4B의 활용 가능성 평가(Evaluation of MedGemma 1.5-4B for Lymph Node Metastasis Prediction in Intrahepatic Cholangiocarcinoma), Domestic, 2026-05-09, RS-2020-KH088723, 우수포스터상, 대한의용생체공학회
    <!-- bac6622f-7f90-5f5c-83cd-e07d87fb3a4e -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 인구통계 특성 및 유관질환이 심방세동 발병에 미치는 영향(The Impact of Demographic Characteristics and Comorbidities on the Incidence of Atrial Fibrillation), Domestic, 2024-11-09, RS-2022-00141473; 2024IP0021, 우수논문상, 대한의용생체공학회
    <!-- 3c29fe36-bc32-5aa7-aefc-da20c5001b08 -->
    - 류가연; 최예은; 신항식(Gayeon Ryu; Ye Eun Choi; Hangsik Shin), 광용적맥파 기반 혈관 나이 추정 모델의 평가(Evaluation of Photoplethysmogram-based Vascular Age Estimation Models), Domestic, 2024-10-23, RS-2024-00423853, 우수논문상, 대한전기학회 정보 및 제어 부문회
    ## Project
    
    1. Development, Optimization and Clinical Verification of Software for Early Diagnosis and Prognosis of Atrial Fibrillation Integrating Gene, Electrocardiogram and Clinical Information Based on Artificial Intelligence, Ministry of Health and Wellfare (MOHW), Korea (Apr 2021 - Dec 2023)
    
    2. Developing artificial intelligence for early risk prediction of atrial fibrillation using clinical information, Asan Medical Center, Korea (Jan 2024 - Dec 2025)
    
    ## Journal
    <!-- 75480fca-4d6e-4b0f-bef4-bd19409c4b34 -->
    - Kim T, Ryu G, Choi YE, Shin H. Medication-specific risk of atrial fibrillation in patients with coronary artery disease. Biomedical Engineering Letters. 2026 Jun; IF:3.4@2025JIF; RS-2024-00335644, 2024IP0021.
--- 
