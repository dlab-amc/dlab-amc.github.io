--- 
layout: member 
title: Jiwon You 
member:
  name_eng: 'Jiwon You'
  degree: 'M.S.'
  profile_image: '/data/members/images/members/profile_image-1753764880571-531382100.jpg'
  hover_image: '/images/members/egg_유지원.JPG'
  role: 'Researcher'
  profile_description: |
    Research Areas : Machine learning, Large Language Model, Bioinformatics
    
    [E-mail](mailto:71one.you@gmail.com)
  contents: |
    ## Journal
    
    - Jiwon You, Yooeun Kim, Kwangsoo Kim, Kyuri Jo. "An Integrated Analysis for Mutational Signatures and Gene Expression Data and Prioritizing Signature-specific Transcription Factors." The Journal of Next-generation Convergence Technology Association, 7.8 (2023):1209-1216.
    
    <!-- 841b7d8e-34dc-46ee-b032-b8a8cdd56a9b -->
    - You J, Seok HS, Kim S, Shin H. Advancing laboratory medicine practice with machine learning: swift yet exact. Annals of Laboratory Medicine. 2024 Nov; 45(1):22-35; IF:4@2023JIF; RS-2024-00335644, 2024IP0001.
    
    <!-- 7766f561-9076-4a25-bfc5-c9a5af6c0b3e -->
    - You J, Shin H. Structural insights into clinical large language models and their barriers to translational readiness. Journal of the American Medical Informatics Association. 2026 Jan; 33(3):732–742; IF:4.6@2024JIF; RS-2024-00335644, 2025IP0016.
    
    
    <!-- 42d3a100-a8ea-4616-88c7-e7817e38f410 -->
    - You J, Shin H. Large language models for interpretation of health checkup results. npj Digital Medicine. 2026 Jul; IF:18@2025JIF; RS-2024-00335644, RS-2020-KH088723, 2025IP0016.
    ## Conference
    
    - Jiwon You, Jeonghwan Yoon, Kyuri Jo. "Computational framework for time course association study between mutational signature and gene expression" Korea Computer Congress (KCC) 2021, June 2021 (2021): 2019-2021.
    
    - Juho Park, Minseok Oh, Jiwon You, Hyoji Kang, Kyuri Jo. "Analysis on Prefrontal Cortex Activation During Musical Improvisation and Sight-Reading Using Multiple Linear Regression" Korea Computer Congress (KCC) 2023, June 2023 (2023): 1853-1855.
    
    - Jiwon You, Yooeun Kim, Kwangsoo Kim, Kyuri Jo. MutTF: a Multi-omics Analysis for Detecting Mutational Signature-induced Gene Regulations by Transcription Factors. The 17th International Conference on Data and Text Mining in Biomedical Informatics (DTMBIO 2023), Dec 18-21, Okinawa, Japan.
    
    <!-- cfc8007b-d815-49b8-bfea-f66cf26e3dcc -->
    - 유지원, 김솔잎, 이우창, 전사일, 신항식. 대학병원 임상화학검사에서 보고된 오류 유형과 빈도. 대한의료정보학회. 2024. 6. 19-21; 가톨릭대학교 성의교정; 2024.
    
    <!-- bdba12ce-ab86-4285-8d84-180fd9189006 -->
    - 석현석, 유지원, 김솔잎, 신항식. 머신러닝을 사용한 진단검사 오류 감지. 2024 대한전기학회 제55회 하계학술대회. 2024. 7. 10-13; 제주국제컨벤션센터(ICC제주); 2024.
    
    <!-- 0a3f5d13-1cc7-4cb3-8767-8f49665f1cf9 -->
    - 유지원, 신항식. 대규모 언어 모델의 건강검진 결과 해석 능력: 가능성과 한계. 2024년도 제64회 대한의용생체공학회 추계학술대회. 2024. 11. 7-9; 서울 스위스 그랜드 호텔; 2024.
    
    <!-- bf623bcc-ddfb-48e7-a65d-18dd48f3cf7b -->
    - 유지원, 신항식. 대규모 언어 모델의 건강 데이터 해석 능력: 다단계 평가 항목을 중심으로. 2025 대한의용생체공학회 춘계학술대회. 2025. 5. 8-10; 제주 롯데호텔; 2025.
    
    <!-- 865070f8-0286-4855-9c26-f82829b67952 -->
    - 유지원, 신항식. Instruction-tuning이 대규모 언어 모델의 건강검진 결과 해석에 미치는 영향. CICS’25 정보 및 제어 학술대회. 2025. 10. 22-25; 고성 델피노리조트; 2025.
    
    <!-- 953bc51d-de68-43ee-a4a5-cc10a73d427a -->
    - 정성연, 유지원, 신항식. LLM 기반 임상화학검사 결과보고서 자동 생성. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 0f8ca978-e12a-49e6-be3a-8fc5cf7da97b -->
    - 유지원, 김솔잎, 신항식. LLM 기반 임상화학검사 재검사 판정 시스템. 2025년 대한의용생체공학회 추계학술대회. 2025. 11. 6-8; 인제대학교; 2025.
    
    <!-- 6f180265-2c3c-4b38-a172-38af22a4c516 -->
    - 정성연, 유지원, 최유나, 김솔잎, 신항식. 귀납적 사례 분석 기반 임상화학 재검사 전문가 지식 추출 및 온톨로지 모델링. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 537dc980-c7f7-4b4b-a328-1f984c75a46c -->
    - 김민소, 유지원, 최유나, 유신애, 박근열, 김솔잎, 신항식. 임상화학검사 불필요 재검 판별을 위한 인공지능 모델 개발 및 다기관 외부 검증. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    <!-- 65be53c6-9dd4-438b-91aa-03e3d8030132 -->
    - 유지원, 정성연, 최유나, 김솔잎, 신항식. 임상화학 검사 재검 판정에서 대규모 언어모델의 유용성 평가. 2026년 대한의용생체공학회 춘계학술대회. 2026. 5. 7-9; 제주 신화월드; 2026.
    
    ## Award
    
    5. KCC2021 학부생/주니어 논문 경진대회 장려상, 한국정보과학회, 2021.07 (논문명: 돌연변이 시그니처와 유전자 발현량의 시계열 연관 분석 프레임워크)
    
    4. 2022 종합학술대회 우수논문상(창업 아이디어 부문), 한국스마트미디어학회, 2022.06 (논문명: 인공지능과 AR 기반 실내 공간정보 제공 앱)
    
    3. KCC2023 학부생/주니어 논문 경진대회 장려상, 한국정보과학회, 2023.07 (논문명: 다중선형회귀 모형을 이용한 피아노 즉흥연주와 재현연주에서의 전전두엽의 뇌활성도 분석)
    
    2. 2025 대한의용생체공학회 추계학술대회 우수포스터상, 대한의용생체공학회, 2025.11 (논문명: LLM 기반 임상화학검사 결과보고서 자동 생성)
    
    <!-- 34dc931e-4d40-4ecd-be98-ec618d6339d4 -->
    - 정성연; 유지원; 신항식(Sungyeon Chung; Jiwon You; Hangsik Shin), LLM 기반 임상화학검사 결과보고서 자동 생성(Clinical Chemistry Report Generation with a Large Language Model), Domestic, 2025-11-08, 2025IP0002; 2024IP0025; RS-2024-00335644, 우수포스터상, 대한의용생체공학회
    <!-- 90c8f0ea-c4de-499e-b7a8-7e265e2cc8d4 -->
    - 유지원; 정성연; 최유나; 김솔잎; 신항식(Jiwon You; Sungyeon Chung; Yuna Choi; Sollip Kim; Hangsik Shin), 임상화학 검사 재검 판정에서 대규모 언어모델의 유용성 평가(Evaluation of the Feasibility of Large Language Models for Re-test Decision in Clinical Chemistry Tests), Domestic, 2026-05-09, RS-2024-00335644; 2025IP0002, 우수논문상, 대한의용생체공학회
    ## Project
    
    6. 비음수 최소제곱법을 활용한 변이 패턴-유전자 발현 시계열 연관 분석, 2021.07~2023.02
    
    4. 음악치료 VR 악기개발을 위한 암기연주와 즉흥연주에서의 뇌파분석 연구, 2022.10~2023.09
    
    5. 코로나 19 멀티오믹스 통합분석 및 예후 예측 모델 개발, 2023.04~2023.08
    
    3. 빅데이터 처리 및 딥러닝/전이학습 모델 개발, 2024.01~2024.12
    
    2. 의학적 진단검사 결과 자동 오류검출 및 피드백 기술 개발, 2024.05~
    
    1. 인공지능 기반 일반화학검사 수기 검증 Human Knowledge Transfer 모델 개발, 2025.01~
--- 
