---
layout: activity_post
type: ai_seminar
title: 'A multimodal sleep foundation model for disease prediction'
date: 2026-01-12 00:00:00
author: '이건'
video_url: 'https://youtu.be/YQs5V8KYJAk'
file_url: 'https://docs.google.com/presentation/d/1J3A9RA5iM5kUBhIRE03CDho37ljYaRwP/edit?usp=drive_link&ouid=100241011738859459601&rtpof=true&sd=true'
ref_url: 'https://www.nature.com/articles/s41591-025-04133-4'
views: 0
comments: true
---

이 논문은 수면다원검사(PSG) 멀티모달 생체신호를 대규모로 자기지도 사전학습해, 수면 단계뿐 아니라 다양한 질병 위험까지 예측하는 채널-비의존적 수면 파운데이션 모델(SleepFM)을 제시합니다.

연구 배경
- PSG는 뇌/심장/호흡/근육 등 여러 생리 신호가 결합된 멀티모달 데이터이며, 수면장애뿐 아니라 정신·신경·심혈관 질환의 조기 신호가 될 수 있습니다.
- 기존 딥러닝 연구는 특정 태스크(수면단계, 무호흡 등)에만 집중하고 라벨링 비용·평가자 변동성·소규모 데이터·코호트 일반화 부족 문제가 있었습니다.
- 수면 분야는 채널 수/구성이 코호트마다 달라 기존 모델이 유연하게 수용하기 어렵고, “수면 자체 예측”을 넘어 질병 예측까지 가능한 FM이 필요했습니다.

데이터 구성
- 5개 코호트에서 6.5만 명 / 58.5만 시간 PSG로 학습(참가자 단위 분할로 데이터 누수 방지).
- Train/Val/Test는 2020년 이전, Temporal test는 2020년 이후 스탠포드 데이터로 시간 분포 변화에 대한 강건성 평가.

전처리
- 저역통과 필터로 aliasing 방지 → 128Hz 리샘플링 → 평균 0/표준편차 1 표준화.
- 결측 채널은 제외(마스크 기반 처리로 가변 채널 지원).

모델 구조(SleepFM)
- 5초 윈도우 토큰화 후 1D CNN 인코더로 채널별 임베딩 생성(Conv1D→BatchNorm→활성화→LayerNorm 반복).
- 채널-비의존적 설계: 입력 채널 개수/순서가 달라도 처리 가능.
- 어텐션 풀링 기반 집계
- 채널별 임베딩 → 모달리티별 임베딩(채널 축 어텐션 풀링 + padding mask)
- 시간축 트랜스포머로 토큰 간 의존성 학습(temporal attention pooling)

학습 목표
- 프리트레이닝: leave-one-out contrastive learning으로 “같은 시점의 다른 모달리티는 가깝게, 다른 시점은 멀게” 학습.

다운스트림
- 수면 단계 예측: 5초 토큰 단위 분류(마스크드 CE)
- 질병 예측: 시간축 풀링 후 예측 + 나이/성별 임베딩 추가(성능 개선 확인)
- 다질병 예측은 Cox PH 기반 손실로 1041개 질병을 각각 학습 후 합산

평가 및 핵심 결과
- 수면 관련 태스크(연령, 성별, 수면 단계, 무호흡)에서 경쟁력 있는 성능을 확보.
- ICD 기반 질병을 유병률 필터링 후 1041개 질병 예측까지 확장했고, 종양/임신/합병증 등 여러 범주에서 높은 예측 성능(C-index/AUROC)을 보였습니다.
- 프리트레이닝에 포함되지 않은 외부 코호트에서도 전이 성능이 강했으나, temporal test(2020년 이후)에서 일부 질병군 성능 저하가 관찰되었습니다.
- 인구통계 기반 모델, end-to-end 지도학습 모델 대비 질병 예측 AUROC가 전반적으로 유의하게 향상되었습니다.

한계점
- 데이터가 “수면장애 의심/모니터링 필요 환자” 중심이라 일반 인구 대표성이 낮습니다.
- 시간 분포가 바뀐 temporal test에서 일부 성능 저하가 존재합니다.
- XAI 적용이 부족해 해석성이 떨어집니다.
