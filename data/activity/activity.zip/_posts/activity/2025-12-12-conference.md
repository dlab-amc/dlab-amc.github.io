---
layout: activity_post
type: conference
title: '테스트 Conference 게시글'
date: 2025-12-12 00:00:00
author: '이연진, 임하민'
extra_info: '테스트 컨퍼런스명'
video_url: 'https://www.youtube.com/watch?v=PeBMYc_hDCw'
views: 0
comments: true
---

테스트입니다.
