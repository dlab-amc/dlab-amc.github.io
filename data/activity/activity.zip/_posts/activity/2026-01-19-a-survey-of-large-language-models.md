---
layout: activity_post
type: ai_seminar
title: 'A survey of Large Language Models'
date: 2026-01-19 00:00:00
author: '류가연'
video_url: 'https://youtu.be/pfvFcD1vK4U'
file_url: 'https://drive.google.com/file/d/1ziKaH4Rn5R6SzVVEHC33xXItbrb1Mx86/view?usp=drive_link'
ref_url: 'https://arxiv.org/abs/2303.18223'
views: 0
comments: true
---

이 논문은 LLM의 발전사를 SLM→신경망 LM→PLM→LLM 흐름으로 정리한 서베이이며, 스케일링·창발적 능력·GPT 계열 발전·프리트레이닝 데이터 설계 원리를 체계적으로 설명합니다.

언어 모델 발전 흐름
- SLM(n-gram)은 짧은 문맥만 반영해 장기 의존성과 데이터 다양성에서 한계가 있습니다.
- 신경망 LM은 임베딩 기반 분산표현으로 일반화 성능을 개선했습니다.
- PLM은 사전학습→파인튜닝 패러다임을 확립했습니다.
- LLM은 일정 스케일 이후 창발적 능력이 등장하며 범용 문제 해결사로 확장됩니다.

PLM vs LLM 차이
- LLM은 ICL·추론 같은 능력이 임계점 이후 비선형적으로 나타납니다.
- 파인튜닝 중심에서 프롬프트 중심 사용으로 전환됩니다.
- 대규모 분산학습이 필수라 연구 구조가 엔지니어링 협업 중심으로 바뀝니다.

핵심 기술 배경
- 트랜스포머 어텐션은 RNN의 순차 처리 한계를 해결하고 긴 문맥을 반영합니다.
- 스케일링 법칙은 Kaplan(모델 확장 유리)과 Chinchilla(데이터·모델 균형)이 대표적입니다.

창발적 능력 3가지
- ICL은 예시만으로 새로운 작업을 수행합니다.
- Instruction tuning은 지시-응답 학습으로 제로샷 일반화를 강화합니다.
- Chain-of-Thought는 단계적 추론을 유도해 복잡한 문제 성능을 올립니다.

LLM 성공을 만든 5가지 요소
- 모델·데이터·연산의 스케일 업이 기본 성능을 끌어올립니다.
- 분산·병렬 학습으로 대규모 학습을 안정화합니다.
- ICL·Instruction·Reasoning으로 능력을 도출합니다.
- RLHF로 안전성과 지시 이행을 강화합니다.
- 외부 도구(검색·계산 등) 활용으로 한계를 보완합니다.

GPT 계열 발전
- GPT1/2는 트랜스포머 기반을 확립했습니다.
- GPT3는 ICL을 본격화했습니다.
- GPT3.5는 RLHF로 대화 안정성을 강화했습니다.
- GPT4는 멀티모달·복잡 문제 해결을 강화했습니다.

Pre-training 데이터 설계
- 데이터는 소스→전처리→스케줄링의 3단계로 관리됩니다.
- 전처리는 저품질 제거, 중복 제거, PII 제거, 서브워드 토크나이징을 포함합니다.
- 스케줄링은 데이터 혼합 비율과 커리큘럼으로 모델 능력 특성을 결정합니다.
